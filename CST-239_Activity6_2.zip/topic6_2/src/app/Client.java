package app;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.net.Socket;

public class Client {
    private Socket socket;
    private PrintWriter out;
    private BufferedReader in;

    // Method to start the client
    public void start(String ipAddress, int port) throws IOException {
        // Create a socket to connect to the server
        socket = new Socket(ipAddress, port);
        System.out.println("Connected to server at " + ipAddress + ":" + port);

        // Create a PrintWriter for sending text over the socket to the server
        out = new PrintWriter(socket.getOutputStream(), true);

        // Create a BufferedReader for receiving text over the socket from the server
        in = new BufferedReader(new InputStreamReader(socket.getInputStream()));

        // Implement message sending and processing logic here
    }

    // Method to send a message to the server and receive a response
    public String sendMessage(String message) throws IOException {
        out.println(message); // Send the message to the server
        String response = in.readLine(); // Receive response from the server
        return response;
    }

    // Method to clean up resources
    public void cleanup() throws IOException {
        // Close the PrintWriter
        if (out != null) {
            out.close();
        }

        // Close the BufferedReader
        if (in != null) {
            in.close();
        }

        // Close the Socket
        if (socket != null) {
            socket.close();
        }
    }

    // Main method to start the client
    public static void main(String[] args) {
        Client client = new Client();
        try {
            client.start("127.0.0.1", 8080); // Connect to server at local IP address and port 6666

            // Send 9 messages to the server
            for (int i = 1; i <= 9; i++) {
                String message = "Message " + i;
                String response = client.sendMessage(message);
                System.out.println("Hello from Client" + response);

                // If it's the 9th message, send the quit message
                if (i == 9) {
                    String quitResponse = client.sendMessage(".");
                    System.out.println("Server Response was " + response);
                }
            }
        } catch (IOException e) {
            e.printStackTrace();
        } finally {
            try {
                client.cleanup(); // Clean up resources
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
        System.exit(0); // Exit the program
    }
}
