package app;

import java.io.IOException;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.ArrayList;
import java.util.List;

public class Server {

    private ServerSocket serverSocket;
    private List<Socket> clientSockets;

    // Constructor
    public Server() {
        clientSockets = new ArrayList<>();
    }

    // Method to start the server on a specified port
    public void start(int port) {
        try {
            // Create a ServerSocket to listen for incoming connections
            serverSocket = new ServerSocket(port);
            System.out.println("Server started on port " + port);

            // Keep accepting incoming connections
            while (true) {
                // Wait for a connection from the client
                Socket clientSocket = serverSocket.accept();
                System.out.println("Client connected: " + clientSocket.getInetAddress());

                // Add client socket to the list
                clientSockets.add(clientSocket);

                // Handle client connection
                handleClient(clientSocket);
            }
        } catch (IOException e) {
            e.printStackTrace();
        } finally {
            cleanup(); // Perform cleanup when server stops
        }
    }

    // Method to handle client connection
    private void handleClient(Socket clientSocket) {
        // Implement the logic for handling client connection here
        // This method will be responsible for processing client requests
    }

    // Method to perform cleanup tasks
    public void cleanup() {
        try {
            // Close the server socket
            if (serverSocket != null && !serverSocket.isClosed()) {
                serverSocket.close();
            }

            // Close all client sockets
            for (Socket clientSocket : clientSockets) {
                if (clientSocket != null && !clientSocket.isClosed()) {
                    clientSocket.close();
                }
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    // Main method to start the server
    public static void main(String[] args) {
        Server server = new Server();
        server.start(7070); // Start the server on port 8888
    }
}