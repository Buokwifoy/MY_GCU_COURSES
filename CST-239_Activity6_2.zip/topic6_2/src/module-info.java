/**
 * 
 */
/**
 * 
 */
module topic6_2 {
}