/**
 * 
 */
/**
 * 
 */
module topic6_1a {
}