package app;
import java.lang.Thread;
public class MyThread1 extends Thread {
 
 // Override the run method
 @Override
 public void run() {
     System.out.println( "MyThread1 is running.");
    
 }
}
