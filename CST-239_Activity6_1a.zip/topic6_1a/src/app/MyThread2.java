package app;

public class MyThread2 implements Runnable {

 private String name;

 // Constructor
 public MyThread2(String name) {
     this.name = name;
 }

 public MyThread2() {
	// TODO Auto-generated constructor stub
}

// Override the run method
 @Override
 public void run() {
     System.out.println("MyThread2 is running.");
    
 }
}

