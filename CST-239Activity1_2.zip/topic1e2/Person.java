package app;

public class Person {
    // Instance variables
    private int age;
    private String name;
    private float weight;
    private String walk;
    private String run;

    // Constructor
    public Person(int age, String name, float weight, String walk, String run) {
        super(); // Calls the constructor of the superclass (Object class)
        this.age = age; // Assigns the age parameter to the age instance variable
        this.name = name; // Assigns the name parameter to the name instance variable
        this.weight = weight; // Assigns the weight parameter to the weight instance variable
        this.walk = walk; // Assigns the walk parameter to the walk instance variable
        this.run = run; // Assigns the run parameter to the run instance variable
    }

    // Getter methods
    public int getAge() {
        return age; // Returns the value of the age instance variable
    }

    public String getName() {
        return name; // Returns the value of the name instance variable
    }

    public float getWeight() {
        return weight; // Returns the value of the weight instance variable
    }

    // Method to simulate walking
    public void Walk() {
        System.out.println("I am in walk()"); // Prints a message indicating the method is invoked
    }

    // Method to simulate running with a specified distance
    public void run(float distance) {
        System.out.println("I am in run()"); // Prints a message indicating the method is invoked
    }

    // Main method
    public static void main(String[] args) {
        // Creating a Person object with specified attributes
        Person person = new Person(25, "Patrick", (float) 165.03, "walk", "run");

        // Printing person's name
        System.out.println("My name is " + person.getName());

        // Calling walk() method
        person.Walk();

        // Calling run() method with a specified distance
        person.run(10);
    }

}
