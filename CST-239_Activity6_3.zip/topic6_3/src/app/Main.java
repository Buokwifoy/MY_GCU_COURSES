package app;

import java.io.IOException;

public class Main {

    public static void main(String[] args) throws IOException {
        Server server = new Server(); // Create an instance of the Server class

        // Create a new thread to start the server
        Thread serverThread = new Thread(() -> {
            server.start(6666); // Start the server on port 6666
        });

        serverThread.start(); // Start the server thread

        try {
            serverThread.join(); // Wait for the server thread to finish
        } catch (InterruptedException e) {
            e.printStackTrace();
        } finally {
            server.cleanup(); // Perform cleanup when server stops
        }

        System.out.println("Exiting the program");
    }
}
