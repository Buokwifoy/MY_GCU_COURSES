
package app;
public class ServerApp {
    public static void main(String[] args) {
        int port = 6060; // Specify the port number

        // Create an instance of ServerThread with the specified port number
        ServerThread serverThread = new ServerThread(port);

        // Start the server thread
        serverThread.start();

        // Print dots to indicate the server is running
        while (serverThread.isAlive()) {
            System.out.print(".");
            try {
                // Sleep for 5 seconds
                Thread.sleep(5000);
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
        }
    }
}
