 package app;
import java.io.IOException;
import java.net.ServerSocket;
import java.net.Socket;

public class ServerThread extends Thread {
    private int port;

    // Constructor that accepts a port number
    public ServerThread(int port) {
        this.port = port;
    }

    @Override
    public void run() {
        try {
            // Create a ServerSocket to listen for client connections
            ServerSocket serverSocket = new ServerSocket(port);
            System.out.println("Server started on port " + port);

            // Accept incoming client connections
            while (true) {
                Socket clientSocket = serverSocket.accept();
                System.out.println("Client connected: " + clientSocket.getInetAddress());

                // Handle client connection (implement this method)
                handleClient(clientSocket);
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    // Method to handle client connection
    private void handleClient(Socket clientSocket) {
        // Implement logic to handle client connection here
    }
}
