// RegularHexagon.java

package shape;

import base.ShapeBase;

public class RegularHexagon extends ShapeBase {
    // Non-default constructor
    public RegularHexagon(String name, int side) {
        super(name, side, side);
    }

    // Calculate area for a regular hexagon
    @Override
    public int calculateArea() {
        return (int) (3 * Math.sqrt(3) * width * width) / 2; // Formula for regular hexagon area
    }
}
