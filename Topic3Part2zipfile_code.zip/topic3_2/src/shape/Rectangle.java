// Rectangle.java

package shape;

import base.ShapeBase;

public class Rectangle extends ShapeBase {
    // Non-default constructor
    public Rectangle(String name, int width, int height) {
        super(name, width, height);
    }

    // Calculate area for a rectangle
    @Override
    public int calculateArea() {
        return width * height;
    }
}
