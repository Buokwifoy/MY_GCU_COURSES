// Circle.java

package shape;

import base.ShapeBase;

public class Circle extends ShapeBase {
    // Non-default constructor
    public Circle(String name, int radius) {
        super(name, radius, radius);
    }

    // Calculate area for a circle
    @Override
    public int calculateArea() {
        return (int) (Math.PI * width * width); // Using Math.PI to represent Pi
    }
}
