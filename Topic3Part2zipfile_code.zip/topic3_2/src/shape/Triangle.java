// Triangle.java

package shape;

import base.ShapeBase;

public class Triangle extends ShapeBase {
    // Non-default constructor
    public Triangle(String name, int width, int height) {
        super(name, width, height);
    }

    // Calculate area for a triangle
    @Override
    public int calculateArea() {
        return (width * height) / 2;
    }
}
