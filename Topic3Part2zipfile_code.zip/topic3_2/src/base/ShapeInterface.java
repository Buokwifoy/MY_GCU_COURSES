// ShapeInterface.java

package base;

public interface ShapeInterface {
    // Define a method to calculate the area
    public int calculateArea();
}
