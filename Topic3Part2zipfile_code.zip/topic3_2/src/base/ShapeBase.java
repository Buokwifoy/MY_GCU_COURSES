// ShapeBase.java

package base;

public class ShapeBase implements ShapeInterface {
    // Protected member variables
    protected int width;
    protected int height;
    protected String name;

    // Non-default constructor
    public ShapeBase(String name, int width, int height) {
        this.name = name;
        this.width = width;
        this.height = height;
    }

    // Getter method for the name member variable
    public String getName() {
        return name;
    }
     // Implementation of calculateArea() method
        @Override
        public int calculateArea() {
            return -1;
    }
}
