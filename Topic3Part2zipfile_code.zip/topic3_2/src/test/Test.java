package test;

import base.ShapeBase;
import shape.Circle;
import shape.RegularHexagon;
import shape.Rectangle; // Import Rectangle class
import shape.Triangle; // Import Triangle class

public class Test {
    public static void main(String[] args) {
        // Create an array of ShapeBase to hold shapes
        ShapeBase[] shapes = new ShapeBase[4];

        // Initialize array elements with instances of different shapes
        shapes[0] = new Rectangle("Rectangle", 5, 4);
        shapes[1] = new Triangle("Triangle", 3, 6);
        shapes[2] = new Circle("Circle", 5);
        shapes[3] = new RegularHexagon("Regular Hexagon", 6);

        // Loop over the shapes array and call the displayArea() method for each shape
        for (ShapeBase shape : shapes) {
            displayArea(shape);
        }
    }

    // Private helper method to display shape's name and area
    private static void displayArea(ShapeBase shape) {
        System.out.println("Shape: " + shape.getName() + ", Area: " + shape.calculateArea());
    }
}
