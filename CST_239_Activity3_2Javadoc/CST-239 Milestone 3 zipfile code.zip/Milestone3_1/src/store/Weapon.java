package store;

class Weapon implements Comparable<Weapon> {
    private int productId;
    private String name;
    private int quantity;

    // Constructor
    public Weapon(int productId, String name, int quantity) {
        this.productId = productId;
        this.name = name;
        this.quantity = quantity;
    }

    // Getters and setters
    public int getProductId() {
        return productId;
    }

    public void setProductId(int productId) {
        this.productId = productId;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public int getQuantity() {
        return quantity;
    }

    public void setQuantity(int quantity) {
        this.quantity = quantity;
    }

    // CompareTo method required by Comparable interface
    @Override
    public int compareTo(Weapon other) {
        // Compare weapons based on their names
        return this.name.compareToIgnoreCase(other.getName());
    }
}