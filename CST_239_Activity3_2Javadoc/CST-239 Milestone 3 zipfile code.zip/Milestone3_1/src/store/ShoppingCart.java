package store;

import java.util.ArrayList;
import java.util.List;

public class ShoppingCart {
    private List<SalableProduct> cartItems;

    // Constructor
    public ShoppingCart() {
        cartItems = new ArrayList<>(); // Initialize the cartItems list
    }

    // Add product to cart
    public void addProduct(SalableProduct product) {
        // Implementation details for adding product to cart
    }

    // Remove product from cart
    public void removeProduct(int productId) {
        // Implementation details for removing product from cart
    }

    // Get cart contents
    public List<SalableProduct> getCartContents() {
        // Implementation details for getting cart contents
        return cartItems;
    }

    // Empty the cart
    public void emptyCart() {
        // Implementation details for emptying the cart
        cartItems.clear(); // Clear the cartItems list to empty the cart
    }
}
