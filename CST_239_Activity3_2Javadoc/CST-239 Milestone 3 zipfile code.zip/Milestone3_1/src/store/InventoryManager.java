package store;

import java.util.ArrayList;
import java.util.List;

public class InventoryManager {
    private List<SalableProduct> inventory;

    // Constructor
    public InventoryManager() {
        inventory = new ArrayList<>(); // Initialize the inventory list
    }

    // Add product to inventory
    public void addProduct(SalableProduct product) {
        // Implementation details for adding product to inventory
    }

    // Remove product from inventory
    public void removeProduct(int productId) {
        // Implementation details for removing product from inventory
    }

    // Get inventory
    public List<SalableProduct> getInventory() {
        // Implementation details for getting inventory
        return inventory;
    }
}
