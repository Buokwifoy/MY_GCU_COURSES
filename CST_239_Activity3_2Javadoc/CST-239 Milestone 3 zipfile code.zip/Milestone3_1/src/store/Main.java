package store;

import java.util.List;

public class Main {
    public static void main(String[] args) {
        // Create some salable products
        SalableProduct product1 = new SalableProduct(1, "Product 1", 45);
        SalableProduct product2 = new SalableProduct(2, "Product 2", 55);
        SalableProduct product3 = new SalableProduct(3, "Product 3", 70);

        // Create an inventory manager and add products to inventory
        InventoryManager inventoryManager = new InventoryManager();
        inventoryManager.addProduct(product1);
        inventoryManager.addProduct(product2);
        inventoryManager.addProduct(product3);

        // Retrieve and display the inventory
        List<SalableProduct> inventory = inventoryManager.getInventory();
        System.out.println("Inventory:");
        for (SalableProduct product : inventory) {
            System.out.println("ID: " + product.getProductId() + ", Name: " + product.getName() + ", Quantity: " + product.getQuantity());
        }

        // Create a shopping cart
        ShoppingCart shoppingCart = new ShoppingCart();

        // Add products to the shopping cart
        shoppingCart.addProduct(product1);
        shoppingCart.addProduct(product2);

        // Retrieve and display the contents of the shopping cart
        List<SalableProduct> cartContents = shoppingCart.getCartContents();
        System.out.println("\nShopping Cart Contents:");
        for (SalableProduct product : cartContents) {
            System.out.println("ID: " + product.getProductId() + ", Name: " + product.getName() + ", Quantity: " + product.getQuantity());
        }

        // Remove a product from the shopping cart
        shoppingCart.removeProduct(product1.getProductId());
        System.out.println("\nProduct 2 removed from the shopping cart.");

        // Retrieve and display the updated contents of the shopping cart
        cartContents = shoppingCart.getCartContents();
        System.out.println("\nUpdated Shopping Cart Contents:");
        for (SalableProduct product : cartContents) {
            System.out.println("ID: " + product.getProductId() + ", Name: " + product.getName() + ", Quantity: " + product.getQuantity());
        }

        // Empty the shopping cart
        shoppingCart.emptyCart();
        System.out.println("\nShopping Cart emptied.");
    }
}
