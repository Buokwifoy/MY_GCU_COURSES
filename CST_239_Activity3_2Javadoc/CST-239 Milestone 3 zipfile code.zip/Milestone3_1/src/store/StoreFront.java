package store;

public class StoreFront {
    // Method to integrate InventoryManager
    public void integrateInventoryManager(InventoryManager manager) {
    }

    // Method to integrate ShoppingCart
    public void integrateShoppingCart(ShoppingCart cart) {
    }
}
