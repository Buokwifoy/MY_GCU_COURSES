package app;

public class MyThread2 implements Runnable {

    private String name;

    // Constructor
    public MyThread2(String name) {
        this.name = name;
    }

    public MyThread2() {
        // Default constructor
    }

    // Override the run method
    @Override
    public void run() {
        System.out.println("MyThread2 is running.");

        // Add a for loop for up to 100 iterations
        for (int x = 1; x <= 1000; x++) {
            // Print a unique message to the console for each iteration
            System.out.println("MyThread2 is running Iteration " + x);
            // Add a sleep to pause execution for 500 milliseconds (0.5 second)
            try {
                Thread.sleep(500);
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
        }
    }
}
