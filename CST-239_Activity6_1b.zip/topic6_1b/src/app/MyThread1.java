package app;

public class MyThread1 extends Thread {
 
    // Override the run method
    @Override
    public void run() {
        System.out.println("MyThread1 is running.");

        // Add a for loop for up to 100 iterations
        for (int x = 1; x <= 1000; x++) {
            // Print a unique message to the console for each iteration
            System.out.println("MyThread1 is running Iteration " + x);
            // Add a sleep to pause execution for 1000 milliseconds (1 second)
            try {
                Thread.sleep(1000);
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
        }
    }
}
