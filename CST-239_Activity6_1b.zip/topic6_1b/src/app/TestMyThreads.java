package app;

public class TestMyThreads {

    public static void main(String[] args) {
        // Create an instance of MyThread1 and start it
        MyThread1 thread1 = new MyThread1();
        thread1.start();

        // Create an instance of MyThread2 and save it in a local variable of type Runnable
      
        Runnable runnable = new MyThread2();

        Thread thread2 = new Thread(runnable);

        // Call the start() method to begin execution of the second thread
        thread2.start();
    }
}
