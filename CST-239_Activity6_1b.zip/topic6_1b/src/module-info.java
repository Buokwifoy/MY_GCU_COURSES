/**
 * 
 */
/**
 * 
 */
module topic6_1b {
}