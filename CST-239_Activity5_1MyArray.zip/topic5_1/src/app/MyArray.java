package app;

public class MyArray {

    // Method to print elements of a generic array
    public <E> void printArray(E[] inputArray) {
        for(E element : inputArray) {
            System.out.printf("%s ", element); // Print each element followed by a space
        }
    }

    public static void main(String[] args) {

        // Define arrays of integers, doubles, and characters
        Integer[] intArray = {1, 2, 3, 4, 5};
        Double[] doubleArray = {1.1, 2.2, 3.3, 4.4, 5.5};
        Character[] charArray = {'W', 'E', 'L', 'L', 'O'};

        // Create an instance of MyArray class
        MyArray ma = new MyArray();

        // Print elements of the integer array
        System.out.println("Array integerArray contains:");
        ma.printArray(intArray);

        // Print elements of the double array
        System.out.println("\nArray doubleArray contains:");
        ma.printArray(doubleArray);

        // Print elements of the character array
        System.out.println("\nArray characterArray contains:");
        ma.printArray(charArray);
    }
}
