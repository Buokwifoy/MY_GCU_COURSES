package mystore;

import java.util.ArrayList;
import java.util.List;

//InventoryManager class manages the inventory of SalableProducts in the store.
class InventoryManager {
// Private list to store SalableProducts
    private List<SalableProduct> products;
// Constructor to initialize the list of products
    public InventoryManager() {
        this.products = new ArrayList<>();
    }
// Method to add a new product to the inventory
    public void addProduct(SalableProduct product) {
        products.add(product);
    }

    public boolean removeProduct(SalableProduct product) {
        return products.remove(product);
    }
 // Method to get a product from the inventory by its name
    public SalableProduct getProduct(String name) {
        for (SalableProduct product : products) {
            if (product.getName().equals(name)) {
                return product;
            }
        }
        return null; // Return null if the product with the given name is not found
    }
}
