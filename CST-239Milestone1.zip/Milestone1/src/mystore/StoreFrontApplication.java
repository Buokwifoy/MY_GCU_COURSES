package mystore;

// StoreFrontApplication class demonstrates the functionality of the store's front-end operations.
public class StoreFrontApplication {
    public static void main(String[] args) {
        // Initialize the store
        StoreFront storeFront = new StoreFront();
        storeFront.initializeStore(); // Initialize store with sample products

        // Create a shopping cart to exercise functions
        ShoppingCart cart = new ShoppingCart();

        // Create sample products
        SalableProduct product1 = new SalableProduct(1, "Furniture", "Dining Table", 1500.99, 1);
        SalableProduct product2 = new SalableProduct(2, "Furniture", "Bedroom Mattress", 1299.99, 1);

        // Add products to the cart
        cart.addItem(product1);
        cart.addItem(product2);

        // Display total price in the cart
        System.out.println("Total Price in the cart: $" + cart.getTotalPrice());

        // Purchase a product
        if (storeFront.purchaseProduct(product1)) {
            System.out.println(product1.getName() + " purchased successfully!");
        } else {
            System.out.println("Failed to purchase " + product1.getName() + ".");
        }

        // Cancel purchase
        if (storeFront.cancelPurchase(product2)) {
            System.out.println("Purchase of " + product2.getName() + " canceled successfully!");
        } else {
            System.out.println("Failed to cancel purchase of " + product2.getName() + ".");
        }

        // Display total price after changes
        System.out.println("Total Price in the cart after changes: $" + cart.getTotalPrice());

        // Checkout
        cart.checkout(); // Simulate checkout process
    }
}
