package app;

public class DriverScript {
    public static void main(String[] args) {
        Car myCar = new Car(); // Create a new Car object named myCar using the Car class constructor.
        
        myCar.start(); // Call the start() method of the myCar object to start the car.
        myCar.run(50); // Call the run(speed) method of the myCar object with a speed of 50 mph.
        myCar.stop(); // Call the stop() method of the myCar object to stop the car.
        myCar.restart(); // Call the restart() method of the myCar object to restart the car.
    }
}
