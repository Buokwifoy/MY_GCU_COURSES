package app;

// Define the Engine class
public class Engine {
    // Private boolean variable to track whether the engine is running
    private boolean running;

    // Method to start the engine
    public void start() {
        // Check if the engine is not already running
        if (!running) {
            // Print a message indicating that the engine is starting
            System.out.println("Engine starting...");
            // Set the running variable to true to indicate that the engine is now running
            running = true;
        } else {
            // If the engine is already running, print a message indicating so
            System.out.println("Engine is already running.");
        }
    }

    // Method to stop the engine
    public void stop() {
        // Check if the engine is currently running
        if (running) {
            // If the engine is running, print a message indicating that the engine is stopping
            System.out.println("Engine stopping...");
            // Set the running variable to false to indicate that the engine has stopped running
            running = false;
        } else {
            // If the engine is already stopped, print a message indicating so
            System.out.println("Engine is already stopped.");
        }
    }

	public boolean isRunning() {
		// TODO Auto-generated method stub
		return false;
	}
}
