package app;

public class Car {
    private Engine engine; // Declare a private instance variable named engine of type Engine.
    private Tire[] tires; // Declare a private instance variable named tires, which is an array of Tire objects.
    private int speed; // Declare a private instance variable named speed of type int.

    public Car() { // Constructor for the Car class
        engine = new Engine(); // Create a new Engine object and assign it to the engine variable.
        tires = new Tire[]{new Tire(34), new Tire(34), new Tire(20), new Tire(34)}; // Create an array of Tire objects and initialize it with specific pressure values.
        speed = 0; // Initialize the speed variable to 0.
    }

    public void start() { // Method to start the car
        for (Tire tire : tires) { // Loop through each tire in the tires array
            tire.checkPressure(); // Check the pressure of each tire.
        }

        if (engine.isRunning()) { // Check if the engine is already running
            System.out.println("Car is already running."); // Print a message indicating that the car is already running.
        } else { // If the engine is not running
            engine.start(); // Start the engine.
            System.out.println("Car started."); // Print a message indicating that the car has started.
        }
    }

    public void run(int speed) { // Method to run the car at a specific speed
        if (engine.isRunning()) { // Check if the engine is running
            this.speed = Math.min(speed, 60); // Set the speed of the car to the minimum of the specified speed and 60 mph.
            System.out.println("Car is running at " + this.speed + " mph."); // Print a message indicating the current speed of the car.
        } else { // If the engine is not running
            System.out.println("Cannot run. Engine is not started."); // Print a message indicating that the car cannot run because the engine is not started.
        }
    }

    public void stop() { // Method to stop the car
        if (engine.isRunning()) { // Check if the engine is running
            engine.stop(); // Stop the engine.
            speed = 0; // Set the speed of the car to 0.
            System.out.println("Car stopped."); // Print a message indicating that the car has stopped.
        } else { // If the engine is not running
            System.out.println("Car is already stopped."); // Print a message indicating that the car is already stopped.
        }
    }

    public void restart() { // Method to restart the car
        if (!engine.isRunning()) { // Check if the engine is not running
            start(); // Start the engine.
            System.out.println("Car restarted."); // Print a message indicating that the car has been restarted.
        } else { // If the engine is already running
            System.out.println("Car is already running."); // Print a message indicating that the car is already running.
        }
    }
}
