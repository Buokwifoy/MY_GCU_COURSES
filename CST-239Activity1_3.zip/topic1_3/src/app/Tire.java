package app;

// Define the Tire class
public class Tire {
    // Private integer variable to store the tire pressure
    private int pressure;

    // Constructor to initialize the Tire object with a pressure value
    public Tire(int pressure) {
        // Set the pressure of the tire to the value passed as parameter
        this.pressure = pressure;
    }

    // Method to check the tire pressure
    public void checkPressure() {
        // Print a message indicating that the tire pressure is being checked
        System.out.println("Checking tire pressure...");
        // Check if the tire pressure is greater than or equal to 32 psi
        if (pressure >= 32) {
            // If the tire pressure is good, print a message indicating so
            System.out.println("Tire pressure is good.");
        } else {
            // If the tire pressure is too low (less than 32 psi), print a message indicating that the engine cannot start
            System.out.println("Tire pressure is too low. Cannot start the engine.");
        }
    }
}
