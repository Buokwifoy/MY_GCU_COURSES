package app;

public class CounterWorker {

    public static void main(String[] args) throws InterruptedException {
        // Print the initial value of the counter
        System.out.println("This is the initial value of the counter " + Counter.getCounterValue());
        int numberCounters = 1000;

        // Create an array containing 1000 instances of CounterThread
        CounterThread[] counter = new CounterThread[numberCounters];
        for (int x = 0; x < 1000; ++x) 
            counter[x] = new CounterThread();
        

        // Start all the CounterThread instances
        for (int x = 0; x < 1000; ++x) 
            counter[x].start();
       

        // Wait for all threads to finish
        for (int x = 0; x < 1000; ++x)
      
                counter[x].join();
          

        // Print the final value of the counter
        System.out.println("This is the end value of the counter " + Counter.getCounterValue());
    }
}
