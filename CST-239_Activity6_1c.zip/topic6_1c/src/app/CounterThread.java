package app;

import java.util.Random;

public class CounterThread extends Thread {
    
    @Override
    public void run() {
        // Generate a random number between 1 and 1000
    	try {
        Random rand = new Random();
        int sleeper  = rand.ints(1, 1000 +1).findFirst().getAsInt();

            // Sleep for the random number of milliseconds
            Thread.sleep(sleeper);
           
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
    	Counter.incrementCounter();
    }
}
