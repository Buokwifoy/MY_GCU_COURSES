package app;

public class Counter {
    private static int count = 0;

    // Synchronized method to increment the counter value
    public static synchronized void incrementCounter() {
        count++;
    }

    // Static method to get the counter value
    public static int getCounterValue() {
        return count;
    }
}
