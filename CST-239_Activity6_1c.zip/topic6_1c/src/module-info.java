/**
 * 
 */
/**
 * 
 */
module topic6_1c {
}