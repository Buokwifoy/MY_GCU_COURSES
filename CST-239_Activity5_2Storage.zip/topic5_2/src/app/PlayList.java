package app;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

public class PlayList {
    public static void main(String[] args) {
        // Create an ArrayList to store playlist songs
        List<Integer> integerList = new ArrayList<Integer>();
        integerList.add(Integer.valueOf(10));
        integerList.add(Integer.valueOf(11));
        
        // Create another ArrayList to store strings
        List<String> stringList = new ArrayList<String>();
        stringList.add("Hello World");
        stringList.add("Hi World");
        
        // Print the first integer and string values
        System.out.printf("Integer Value: %d\n", integerList.get(0));
        System.out.printf("String Value: %s\n", stringList.get(0));              
        
        // Printing Integer List using enhanced for loop
        for(Integer data : integerList) {
            System.out.printf("Integer Value: %d\n", data);
        }
        
        // Using Iterator to print String List
        Iterator<String> stringIterator = stringList.iterator();
        while (stringIterator.hasNext()) {
            System.out.printf("String Value: %s\n", stringIterator.next());
        }
    }
}
