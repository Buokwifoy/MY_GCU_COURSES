package app;

import java.util.Iterator;
import java.util.Stack;

public class PlayStack {

    public static void main(String[] args) {
        // Create a Stack of Strings
        Stack<String> stringStack = new Stack<>();
        stringStack.push("Mark Reha"); // Adding elements to the stringStack
        stringStack.push("Mary Reha");
        stringStack.push("Justine Reha");
        stringStack.push("Brianna Reha");

        // Create a Stack of Integers
        Stack<Integer> integerStack = new Stack<>();
        integerStack.push(1); // Adding elements to the integerStack
        integerStack.push(-1);
        integerStack.push(5);
        integerStack.push(10);

        // Print the integerStack
        System.out.println(integerStack); // Printing the integerStack
        System.out.printf("Integer Stack Tests: size is %d and head element is %d\n", integerStack.size(), integerStack.elementAt(1)); // Printing the size and head element of the integerStack

        // Iterate over the stringStack using an Iterator
        Iterator<String> itr = stringStack.iterator(); // Creating an Iterator for the stringStack
        System.out.println("String Stack Elements:");
        while (!stringStack.isEmpty()) { // Loop through the stringStack elements
            System.out.println(stringStack.pop()); // Printing and removing each element of the stringStack
        }
    }
}
