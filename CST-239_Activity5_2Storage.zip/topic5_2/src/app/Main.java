package app;

import java.util.ArrayList;

public class Main {
    public static void main(String[] args) {
        // Create an ArrayList of Strings
        ArrayList<String> stringList = new ArrayList<>();

        // Add elements to the ArrayList
        stringList.add("Apple");
        stringList.add("Banana");
        stringList.add("Orange");
        stringList.add("Grapes");
        stringList.add("Pineapple");

        // Print the String List using a while loop
        System.out.println("String List:");
        int index = 0;
        while (index < stringList.size()) {
            System.out.println(stringList.get(index));
            index++;
        }
    }
}
