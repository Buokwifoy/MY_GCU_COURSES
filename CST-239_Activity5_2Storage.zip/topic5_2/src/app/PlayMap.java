package app;

import java.util.HashMap;
import java.util.Map;

public class PlayMap {
    public static void main(String[] args) {
        // Create a HashMap to store integers
        Map<Integer, Integer> integerMap = new HashMap<>();
        integerMap.put(1, 1);
        integerMap.put(2, 2);
        
        // Create a HashMap to store strings
        Map<Integer, String> stringMap = new HashMap<>();
        stringMap.put(1, "One");
        stringMap.put(2, "Two");
        
        // Create a HashMap to store names
        Map<String, String> nameMap = new HashMap<>();
        nameMap.put("FirstName", "Mark");
        nameMap.put("LastName", "Reha");
        
        // Print the size and whether each map is empty
        System.out.printf("Name Map Test: size is %d and is empty %b\n", nameMap.size(), nameMap.isEmpty());
        
        // Print the key-value pairs of the nameMap
        for (Map.Entry<String, String> entry : nameMap.entrySet()) {
            System.out.printf("Key: %s Value: %s\n", entry.getKey(), entry.getValue());
        }
        
        // Clear all maps
        integerMap.clear();
        stringMap.remove(1);
        stringMap.clear();
        nameMap.clear();
    }
}
