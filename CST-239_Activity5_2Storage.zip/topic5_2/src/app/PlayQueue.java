package app;

import java.util.Iterator;
import java.util.LinkedList;
import java.util.Queue;

public class PlayQueue {

    public static void main(String[] args) {
        // Create a Queue of Strings
        Queue<String> stringQueue = new LinkedList<>();
        stringQueue.offer("Mark Reha"); // Adding elements to the stringQueue
        stringQueue.add("Mary Reha");
        stringQueue.offer("Justine Reha");
        stringQueue.add("Brianna Reha");

        // Create a Queue of Integers
        Queue<Integer> integerQueue = new LinkedList<>();
        integerQueue.add(1); // Adding elements to the integerQueue
        integerQueue.offer(-1);
        integerQueue.add(5);
        integerQueue.offer(10);

        // Print the integerQueue
        System.out.println(integerQueue); // Printing the integerQueue
        System.out.printf("Integer Queue Tests: size is %d and head element is %d\n", integerQueue.size(), integerQueue.peek()); // Printing the size and head element of the integerQueue

        // Iterate over the stringQueue using an Iterator
        Iterator<String> itr = stringQueue.iterator(); // Creating an Iterator for the stringQueue
        System.out.println("String Queue Elements:");
        while (itr.hasNext()) { // Loop through the stringQueue elements using the Iterator
            System.out.println(itr.next()); // Printing each element of the stringQueue
        }
    }
}
