package app;

public class Health extends SalableProduct {
    private double healingPower;

    // Constructor
    public Health(String name, String description, double price, int quantity, double healingPower) {
        super(name, description, price, quantity);
        this.healingPower = healingPower;
    }

    // Getter and setter for healingPower
    public double getHealingPower() {
        return healingPower;
    }

    public void setHealingPower(double healingPower) {
        this.healingPower = healingPower;
    }

    @Override
    public String toString() {
        return "Health{" +
                "name='" + getName() + '\'' +
                ", description='" + getDescription() + '\'' +
                ", price=" + getPrice() +
                ", quantity=" + getQuantity() +
                ", healingPower=" + healingPower +
                '}';
    }
}
