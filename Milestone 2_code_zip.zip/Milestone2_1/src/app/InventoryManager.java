package app;

import java.util.ArrayList;
import java.util.List;

public class InventoryManager {
    private List<SalableProduct> inventory;

    // Constructor
    public InventoryManager() {
        this.inventory = new ArrayList<>();
    }

    // Method to populate the inventory
    public void populateInventory() {
        // Hard-coded initial inventory items
        // You can replace this with your actual logic to populate the inventory
        inventory.add(new SalableProduct("Sword", "Sharp and deadly", 50.0, 10));
        inventory.add(new SalableProduct("Shield", "Protects from harm", 30.0, 5));
        inventory.add(new SalableProduct("Health Potion", "Restores health", 10.0, 20));
        
    }

    // Method to purchase a product
    public boolean purchaseProduct(String productName, int quantity) {
        for (SalableProduct product : inventory) {
            if (product.getName().equalsIgnoreCase(productName)) {
                if (product.getQuantity() >= quantity) {
                    product.setQuantity(product.getQuantity() - quantity);
                    return true; // Purchase successful
                } else {
                    return false; // Not enough quantity in stock
                }
            }
        }
        return false; // Product not found
    }

    // Method to cancel a purchase
    public boolean cancelPurchase(String productName, int quantity) {
        for (SalableProduct product : inventory) {
            if (product.getName().equalsIgnoreCase(productName)) {
                product.setQuantity(product.getQuantity() + quantity);
                return true; // Cancellation successful
            }
        }
        return false; // Product not found
    }
}
