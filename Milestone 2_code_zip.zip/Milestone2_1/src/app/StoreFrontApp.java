package app;

import java.util.Scanner;

public class StoreFrontApp {
    private InventoryManager inventoryManager;
   

    // Constructor
    public StoreFrontApp() {
        this.inventoryManager = new InventoryManager();
      
    }

    // Method to start the StoreFrontApp
    public void start() {
        displayWelcomeMessage();

        // Populate the inventory
        inventoryManager.populateInventory();

        Scanner scanner = new Scanner(System.in);
        boolean running = true;

        while (running) {
            displayActions();
            String userInput = scanner.nextLine();

            switch (userInput.toLowerCase()) {
                case "1":
                    purchaseProduct(scanner);
                    break;
                case "2":
                    cancelPurchase(scanner);
                    break;
                case "3":
                    System.out.println("Thank you for visiting Buofinity Store Front!");
                    running = false;
                    break;
                default:
                    System.out.println("Invalid input. Please try again.");
            }
        }

        scanner.close();
    }

    // Method to display welcome message
    private void displayWelcomeMessage() {
        System.out.println("Welcome to Buofinity Store Front Application");
        System.out.println(":::::::::::::::::::::::::::::::::::::::::::::::");
    }

    // Method to display actions for the user
    private void displayActions() {
        System.out.println("What do you want to do? Please select your option");
        System.out.println("1. Purchase a product");
        System.out.println("2. Cancel a purchase");
        System.out.println("3. Exit");
    }

    // Method to purchase a product
    private void purchaseProduct(Scanner scanner) {
        // Placeholder method for purchasing a product
        System.out.println("Purchase feature is under construction.");
    }

    // Method to cancel a purchase
    private void cancelPurchase(Scanner scanner) {
        // Placeholder method for canceling a purchase
        System.out.println("Cancel purchase feature is under construction.");
    }

    // Main method to start the application
    public static void main(String[] args) {
        StoreFrontApp storeFrontApp = new StoreFrontApp();
        storeFrontApp.start();
    }
}
