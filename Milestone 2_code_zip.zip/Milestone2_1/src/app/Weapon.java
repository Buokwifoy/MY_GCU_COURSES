package app;

public class Weapon extends SalableProduct {
    private double damage;

    // Constructor
    public Weapon(String name, String description, double price, int quantity, double damage) {
        super(name, description, price, quantity);
        this.damage = damage;
    }

    // Getter and setter for damage
    public double getDamage() {
        return damage;
    }

    public void setDamage(double damage) {
        this.damage = damage;
    }

    @Override
    public String toString() {
        return "Weapon{" +
                "name='" + getName() + '\'' +
                ", description='" + getDescription() + '\'' +
                ", price=" + getPrice() +
                ", quantity=" + getQuantity() +
                ", damage=" + damage +
                '}';
    }
}
