package app;

public class Armor extends SalableProduct {
    private double defense;

    // Constructor
    public Armor(String name, String description, double price, int quantity, double defense) {
        super(name, description, price, quantity);
        this.defense = defense;
    }

    // Getter and setter for defense
    public double getDefense() {
        return defense;
    }

    public void setDefense(double defense) {
        this.defense = defense;
    }

    @Override
    public String toString() {
        return "Armor{" +
                "name='" + getName() + '\'' +
                ", description='" + getDescription() + '\'' +
                ", price=" + getPrice() +
                ", quantity=" + getQuantity() +
                ", defense=" + defense +
                '}';
    }
}
