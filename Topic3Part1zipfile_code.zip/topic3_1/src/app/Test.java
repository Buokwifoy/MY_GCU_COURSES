package app;

import java.util.Arrays;

public class Test {
    public static void main(String[] args) {
        // Create instances of Person
        Person[] persons = new Person[4];
        persons[0] = new Person("Justine", "Reha");
        persons[1] = new Person("Brianna", "Reha");
        persons[2] = new Person("Mary", "Reha");
        persons[3] = new Person("Mark", "Reha");

        // Sort the array by last name
        Arrays.sort(persons);

        // Print the sorted array
        System.out.println("Sorted by last name:");
        for (Person person : persons) {
            System.out.println(person);
        }

        // Reorder the array by first name
        Arrays.sort(persons, (p1, p2) -> p1.getFirstName().compareTo(p2.getFirstName()));

        // Print the array sorted by first name
        System.out.println("\nSorted by first name:");
        for (Person person : persons) {
            System.out.println(person);
        }
    }
}
