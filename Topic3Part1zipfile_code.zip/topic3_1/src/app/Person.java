package app;

public class Person implements PersonInterface, Comparable<Person> {
    // Private member variables to track running state and personal information
    private boolean running;
    private String firstName;
    private String lastName;

    // Constructor to initialize firstName and lastName
    public Person(String firstName, String lastName) {
        this.firstName = firstName;
        this.lastName = lastName;
    }

    // Copy constructor
    public Person(Person person) {
        this.firstName = person.getFirstName();
        this.lastName = person.getLastName();
    }

    // Getter method for firstName
    public String getFirstName() {
        return firstName;
    }

    // Getter method for lastName
    public String getLastName() {
        return lastName;
    }

    // Implementing methods from PersonInterface
    @Override
    public void walk() {
        System.out.println("I am walking");
        running = false;
    }

    @Override
    public void run() {
        System.out.println("I am running");
        running = true;
    }

    @Override
    public boolean isRunning() {
        return running;
    }

    // Implementing Comparable interface
    @Override
    public int compareTo(Person p) {
        // Compare based on last name first
        int value = this.lastName.compareTo(p.lastName);
        
        // If last names are the same, compare based on first name
        if (value == 0) {
            return this.firstName.compareTo(p.firstName);
        } else {
            return value;
        }
    }

    // Override equals() method to compare Person objects
    @Override
    public boolean equals(Object other) {
        if (this == other) {
            return true;
        }
        if (other == null || getClass() != other.getClass()) {
            return false;
        }
        Person person = (Person) other;
        return firstName.equals(person.firstName) && lastName.equals(person.lastName);
    }

    // Override toString() method to represent Person object as a String
    @Override
    public String toString() {
        return firstName + " " + lastName;
    }
}
