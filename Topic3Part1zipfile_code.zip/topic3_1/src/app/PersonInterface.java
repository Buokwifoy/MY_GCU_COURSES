package app;

public interface PersonInterface {
    // Behavior methods
    public void walk();
    public void run();
    public boolean isRunning();
}
