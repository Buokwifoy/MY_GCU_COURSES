package app;

public class Person {
    private int age;
    private String name;
    private float weight;
    private String walk;
    private String run;

    // Constructor
    public Person(int age, String name, float weight, String walk, String run) {
        super();
        this.age = age;
        this.name = name;
        this.weight = weight;
        this.walk = walk;
        this.run = run;
    }

    // Getter methods
    public int getAge() {
        return age;
    }

    public String getName() {
        return name;
    }

    public float getWeight() {
        return weight;
    }

    public void Walk() {
        System.out.println("I am in walk()");
    }

    public void run(float distance) {
    	System.out.println("I am in run()"); 
    }

    // Main method
    public static void main(String[] args) {
        // Creating a Person object
        Person person = new Person(25, "Patrick", (float) 165.03, "walk", "run");

        // Printing person's name
        System.out.println("My name is " + person.getName());

        // Calling walk() method
        person.Walk();

        // Calling run() method
        person.run(10);
    }

	}
//Provide a brief (3- to 4-sentence) description of how and why the output was displayed.

/* The reason we see this result is because the main function generates a fresh instance of a Person with specific characteristics:
 *  aged 25, named "Patrick", weighing 165.03, and capable of performing actions like walking and running. Subsequently, 
 *  it utilizes the getName() method to fetch the individual's name and displays it. Following that, it prompts the person 
 *  to walk, leading to the display of "I am in walk()". 
 *   Lastly, it instructs the person to run a distance of 10, resulting in the output "I am in run()". 
 * */
 