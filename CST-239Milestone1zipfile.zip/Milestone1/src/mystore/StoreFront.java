package mystore;

// StoreFront class represents the front-end of the store, managing inventory and purchases.
class StoreFront {
    private InventoryManager inventoryManager; // Private attribute to manage inventory

    // Constructor initializes the InventoryManager
    public StoreFront() {
        this.inventoryManager = new InventoryManager();
    }

    // Method to initialize the store with sample products
    public void initializeStore() {
        // Implement store initialization logic here
        // For now, let's add some sample products to the inventory
        inventoryManager.addProduct(new SalableProduct(1, "Furniture", "Dining Table", 1500.99, 10));
        inventoryManager.addProduct(new SalableProduct(2, "Furniture", "Bedroom Mattress", 1299.99, 5));
    }

    // Method to purchase a product from the inventory
    public boolean purchaseProduct(SalableProduct product) {
        // Implement purchase logic here
        // Checks if the product exists in inventory and has available quantity
        if (inventoryManager.getProduct(product.getName()) != null && product.getQuantity() > 0) {
            product.setQuantity(product.getQuantity() - 1); // Decrease quantity after purchase
            return true; // Return true indicating successful purchase
        }
        return false; // Return false indicating failed purchase
    }

    // Method to cancel a purchase and return the product to inventory
    public boolean cancelPurchase(SalableProduct product) {
        // Implement cancel purchase logic here
        // Checks if the product exists in inventory
        if (inventoryManager.getProduct(product.getName()) != null) {
            product.setQuantity(product.getQuantity() + 1); // Increase quantity after cancellation
            return true; // Return true indicating successful cancellation
        }
        return false; // Return false indicating failed cancellation
    }
}
