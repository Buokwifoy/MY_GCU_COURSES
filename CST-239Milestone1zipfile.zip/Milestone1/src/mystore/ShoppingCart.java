package mystore;

import java.util.ArrayList;
import java.util.List;

// ShoppingCart class represents a shopping cart where customers can add and remove SalableProducts.
class ShoppingCart {
    // Private list to store items in the shopping cart
    private List<SalableProduct> items;

    // Constructor to initialize the list of items
    public ShoppingCart() {
        this.items = new ArrayList<>();
    }

    // Method to add a SalableProduct to the shopping cart
    public void addItem(SalableProduct product) {
        items.add(product);
    }

    // Method to remove a SalableProduct from the shopping cart
    public boolean removeItem(SalableProduct product) {
        return items.remove(product);
    }

    // Method to calculate the total price of all items in the shopping cart
    public double getTotalPrice() {
        double totalPrice = 0;
        for (SalableProduct item : items) {
            totalPrice += item.getPrice();
        }
        return totalPrice;
    }

    // Method to simulate the checkout process
    public void checkout() {
        // Implement checkout logic here
        // For now, let's just print a message
        System.out.println("Checkout successful. Thank you for shopping with us!");
    }
}
