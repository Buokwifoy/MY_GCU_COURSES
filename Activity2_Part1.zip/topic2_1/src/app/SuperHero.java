package app;

import java.util.Random;

public class SuperHero {
    private String name;
    private int health;
    private boolean isDead;

    public SuperHero(String name, int health) {
        this.name = name;
        this.health = health;
    }

    public void attack(SuperHero opponent) {
        Random random = new Random();
        int damage = random.nextInt(10) + 1;
        opponent.determineHealth(damage);

        System.out.println(this.name + " attacks " + opponent.getName() + " and inflicts " + damage + " damage.");
        System.out.println(opponent.getName() + " now has " + opponent.getHealth() + " health.");
    }

    public boolean isDead() {
        return this.isDead;
    }

    private void determineHealth(int damage) {
        if (this.health - damage <= 0) {
            this.health = 0;
            this.isDead = true;
        } else {
            this.health -= damage;
        }
    }

    public String getName() {
        return name;
    }

    public int getHealth() {
        return health;
    }
}

