package app;

import java.util.Random;

public class Superman extends SuperHero {
    public Superman(int health) {
        super("Superman", health);
    }

    public static void main(String[] args) {
        // TODO Auto-generated method stub
    }
}
