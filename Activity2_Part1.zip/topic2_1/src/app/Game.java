package app;

import java.util.Random;

public class Game {

    public static void main(String[] args) {
        // Create instances of Superman and Batman with random health between 1 and 1000
        Superman superman = new Superman(generateRandomHealth());
        Batman batman = new Batman(generateRandomHealth());

        // Run game logic
        while (!superman.isDead() && !batman.isDead()) {
            superman.attack(batman);
            if (!batman.isDead()) {
                batman.attack(superman);
            }
        }

        // Print game results
        if (superman.isDead() && batman.isDead()) {
            System.out.println("Both Superman and Batman are dead. It's a draw!");
        } else if (superman.isDead()) {
            System.out.println("Superman is dead. Batman wins!");
        } else {
            System.out.println("Batman is dead. Superman wins!");
        }
    }

    // Method to generate random health between 1 and 1000
    private static int generateRandomHealth() {
        Random random = new Random();
        return random.nextInt(1000) + 1;
    }
}
