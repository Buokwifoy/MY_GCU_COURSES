package app;

public class Gun extends Weapon {

    // Overridden fireWeapon() method from the Weapon class
    @Override
    public void fireWeapon(int power) {
        System.out.println("Gun fired with power: " + power);
    }

    // Implementation of the activate() method
    @Override
    public void activate(boolean enable) {
        System.out.println("Gun activate() method called with enable value: " + enable);
    }

	public void fireWeapon() {
		// TODO Auto-generated method stub
		
	}
}
