package app;

public class Bomb extends Weapon {

    // Overridden fireWeapon() method from the Weapon class
    @Override
    public void fireWeapon(int power) {
        System.out.println("Bomb exploded with power: " + power);
    }

    // Overloaded fireWeapon() method with no parameters
    public void fireWeapon() {
        System.out.println("In overloaded Bomb, fireWeapon()");
        super.fireWeapon (0); // Calling the base class's fireWeapon() method with power 0
    }

    // Implementation of the activate() method
    @Override
    public void activate(boolean enable) {
        System.out.println("Bomb activate() method called with enable value: " + enable);
    }
}

