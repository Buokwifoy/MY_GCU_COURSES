package base;

public interface WeaponInterface {
    // Method to fire weapon without power argument
    public void fireWeapon();

    // Method to fire weapon with power argument
    public void fireWeapon(int power);

    // Method to activate weapon
    public void activate(boolean enable);
}
