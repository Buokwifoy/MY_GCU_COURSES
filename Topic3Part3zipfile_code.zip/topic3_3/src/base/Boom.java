package base;

public class Boom implements WeaponInterface {

    // Implementation of the fireWeapon() method with power argument
    @Override
    public void fireWeapon(int power) {
        System.out.println("In Boom.fireWeapon() with power of " + power);
    }

    // Implementation of the fireWeapon() method without power argument
    @Override
    public void fireWeapon() {
        System.out.println("In Boom.fireWeapon()");
    }

    // Implementation of the activate() method
    @Override
    public void activate(boolean enable) {
        System.out.println("In Boom.activate() with enable value of " + enable);
    }
}
