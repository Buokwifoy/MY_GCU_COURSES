package base;

public class Gun implements WeaponInterface {

    // Implementation of the fireWeapon() method with power argument
    @Override
    public void fireWeapon(int power) {
        System.out.println("In Gun.fireWeapon() with a power of " + power);
    }

    // Implementation of the fireWeapon() method without power argument
    @Override
    public void fireWeapon() {
        System.out.println("In Gun.fireWeapon()");
    }

    // Implementation of the activate() method
    @Override
    public void activate(boolean enable) {
        System.out.println("In Gun.activate() with an enable of " + enable);
    }
}
