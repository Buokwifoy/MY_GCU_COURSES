package base;

public class Game {
    public static void main(String[] args) {
        // Method scoped variable that is an array of type WeaponInterface named weapons that can hold 2 weapons
        WeaponInterface[] weapons = new WeaponInterface[2];

        // Initialize the first array element with an instance of a Bomb class
        weapons[0] = new Boom();

        // Initialize the second array element with an instance of a Gun class
        weapons[1] = new Gun();

        // Loop over the weapons array and call the private fireWeapon() helper method for each weapon
        for (int i = 0; i < weapons.length; i++) {
            fireWeapon(weapons[i]);
        }
    }

    // Private helper method to activate and fire a weapon
    private static void fireWeapon(WeaponInterface weapon) {
        weapon.activate(true); // Activate the weapon
        weapon.fireWeapon(5);   // Fire the weapon
    }
}
